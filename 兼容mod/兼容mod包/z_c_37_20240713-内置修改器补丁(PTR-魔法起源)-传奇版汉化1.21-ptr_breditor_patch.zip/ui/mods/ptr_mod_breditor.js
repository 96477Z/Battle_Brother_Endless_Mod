WorldBreditorScreen.prototype.FirstPerkButton = function (_moveforward)
{
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	if (_moveforward)
	{
		this.mPerkButtons[0].Counter +=1;
		if (this.mPerkButtons[0].Counter == pt_classnames.length)
		{
			this.mPerkButtons[0].Counter = 0;
		}
	}
	else
	{
		this.mPerkButtons[0].Counter -=1;
		if (this.mPerkButtons[0].Counter == -1)
		{
			this.mPerkButtons[0].Counter = pt_classnames.length - 1;
		}
	}

	this.mPerkButtons[0].Button.changeButtonText(BEFanYi(pt_classnames[this.mPerkButtons[0].Counter]));
	this.mPerkButtons[1].Counter = 0;
	var tempo = this.mPTree[pt_classnames[this.mPerkButtons[0].Counter]][this.mPerkButtons[1].Counter].ID;
	this.mPerkButtons[1].Button.changeButtonText(BEFanYi(tempo.replace('Tree','').replace('Class','')));
	this.CorrectDisplayedPerks();
};

WorldBreditorScreen.prototype.SecondPerkButton = function (_moveforward)
{
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	var pt_subclasses = this.mPTree[pt_classnames[this.mPerkButtons[0].Counter]].length;
	if (_moveforward)
	{
		this.mPerkButtons[1].Counter +=1;
		if (this.mPerkButtons[1].Counter == pt_subclasses)
		{
			this.mPerkButtons[1].Counter = 0;
		}
	}
	else
	{
		this.mPerkButtons[1].Counter -=1;
		if (this.mPerkButtons[1].Counter == -1)
		{
			this.mPerkButtons[1].Counter = pt_subclasses - 1;
		}
	}
	
	var tempo = this.mPTree[pt_classnames[this.mPerkButtons[0].Counter]][this.mPerkButtons[1].Counter].ID;
	this.mPerkButtons[1].Button.changeButtonText(BEFanYi(tempo.replace('Tree','').replace('Class','')));
	this.CorrectDisplayedPerks();
};

WorldBreditorScreen.prototype.CorrectDisplayedPerks = function ()
{
	var self = this;
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	var perkcounter = 0;
	
	var plzsendhelp = {
		BroId: this.mData.ID,
		ButOne: pt_classnames[this.mPerkButtons[0].Counter],
		ButTwo: this.mPerkButtons[1].Counter,
	}
	this.notifyBackendOnBadBadPerks(plzsendhelp, function(_result)
        {           
			var perkcounter = 0;
			for (var p = 2; p < self.mPerkButtons.length; p++) 
			{
				var perk = self.mPerkButtons[p];
				if (perkcounter < _result.length)
				{
					perk.Image.attr('src', Path.GFX + _result[perkcounter].Icon); 
					perk.Image.bindTooltip({ contentType: 'ui-perk', entityId: self.mRoster[self.mRoster.length-1].ID, perkId: _result[perkcounter].ID });
				}
				else
				{
					perk.Image.attr('src', Path.GFX+'ui/icons/talent_0.png');
					perk.Image.unbindTooltip();
				}
				perkcounter +=1;
			} 
        }); 
};

WorldBreditorScreen.prototype.AddPG = function ()
{
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	
	var sendingdhelp = {
		BroId: this.mData.ID,
		ButOne: pt_classnames[this.mPerkButtons[0].Counter],
		ButTwo: this.mPerkButtons[1].Counter,
	}
	this.notifyBackendOnAcceptingPG(sendingdhelp);
	this.CorrectDisplayedPerks();
};

WorldBreditorScreen.prototype.RemovePG = function ()
{
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	var self = this;
	var data = this.mData;
	var sendingdhelp = {
		BroId: this.mData.ID,
		ButOne: pt_classnames[this.mPerkButtons[0].Counter],
	}
	this.notifyBackendOnRemovingPG(sendingdhelp, function(_result)
        {           
            data.PerkPoints = _result.PerkPoints;
			self.mStatsOptions.PerkPoints.SVal.html(data.PerkPoints);
        }); 
	
	this.CorrectDisplayedPerks();
};

WorldBreditorScreen.prototype.AddPerk = function (_counter)
{
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	var sendingdhelp = {
		BroId: this.mData.ID,
		ButOne: pt_classnames[this.mPerkButtons[0].Counter],
		ButTwo: this.mPerkButtons[1].Counter,
		PerkId: _counter,
	}
	var self = this;
	var data = this.mData;
	this.notifyBackendOnAddingPerk(sendingdhelp, function(_result)
        {           
            data.PerkPoints = _result.PerkPoints;
			self.mStatsOptions.PerkPoints.SVal.html(data.PerkPoints);
        }); 
	this.CorrectDisplayedPerks();
};

WorldBreditorScreen.prototype.loadFromData = function (_data)
{
	if(_data === undefined || _data === null)
    {
        return;
    }

	if('Title' in _data && _data.Title !== null)
	{
		 this.mDialogContainer.findDialogTitle().html(_data.Title);
	}

/* 	if('SubTitle' in _data && _data.SubTitle !== null)
	{
		 this.mDialogContainer.findDialogSubTitle().html(_data.SubTitle);
	} */
	this.mMode = 1;
	this.mRoster = _data.Roster;
	this.mTraits = _data.Traits;
	this.mBackgrounds = _data.Backgrounds;
	this.mNItems = _data.NamedItems;
	this.mPTree = _data.PTree;
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	this.mPerkButtons[0].Button.changeButtonText(BEFanYi(pt_classnames[this.mPerkButtons[0].Counter]));
	var tempo = this.mPTree[pt_classnames[this.mPerkButtons[0].Counter]][this.mPerkButtons[1].Counter].ID;
	this.mPerkButtons[1].Button.changeButtonText(BEFanYi(tempo.replace('Tree','').replace('Class','')));
	
	var traitcounter = 0;
	var traitslength = this.mTraits.length;
	for (var r = 0; r < this.mTraitOptions.length; r++) 
	{
		for (var trid = 1; trid < this.mTraitOptions[r].length; trid++) 
		{
 			var trait = this.mTraitOptions[r][trid];
			trait.Image.attr('src', Path.GFX+'ui/icons/talent_0.png');
			if (traitcounter < traitslength)
			{
				trait.Image.attr('src', Path.GFX+this.mTraits[traitcounter][2]);
				trait.Image.bindTooltip({ contentType: 'status-effect', entityId: _data.Roster[_data.Roster.length-1].ID, statusEffectId: this.mTraits[traitcounter][0] });
				trait.Container.css({ opacity: 0.33 });
				traitcounter +=1;
			}
		}
	}
	this.setupSkillEventHandlers();
	
	this.mNamedItemsPanel.Rows[0][1].TBValue = 0;
	this.mNamedItemsPanel.Rows[0][1].TypeButton.changeButtonText("武器");
	this.mNamedItemsPanel.Rows[1][1].TBValue = 0;
	this.RerollNIData();
	this.mNamedItemsPanel.Rows[0][4].BroExpImpInput.setInputTextBP("");
	//this.mNamedItemsPanel.Rows[1][1].TypeButton.changeButtonText(this.mNItems.Items["Weapons"].List[0]);
	
	//this.mStatsOptions.Hitpoints.TraitContainer[2].Image.attr('src', Path.GFX + Asset.ICON_FATIGUE); //self.mTraits[1][2]
	
	
    this.mListScrollContainer.empty();

    for(var i = 0; i < _data.Roster.length - 1; ++i)
    {
		var entry = _data.Roster[i];
        this.addListEntry(entry);
    }

    this.selectListEntry(this.mListContainer.findListEntryByIndex(0), true);
};

WorldBreditorScreen.prototype.attachPerkEventHandler = function(_perk)
{
	var self = this;
	var pt_classnames = ['Weapons', 'Armor', 'Traits', 'Class', 'Enemy', 'Magic', 'Styles', 'Profession', 'Special', 'Leftovers'];
	_perk.Container.click(this, function (_event)
	{
		var perkcounter = 0;
		for (var p = 2; p < self.mPerkButtons.length; p++) 
		{
			var perk = self.mPerkButtons[p];
			var secondcounter = 0;
			var tempo = self.mPTree[pt_classnames[self.mPerkButtons[0].Counter]][self.mPerkButtons[1].Counter].Tree;
			for (var r = 0; r < tempo.length; r++) 
			{
				for (var c = 0; c < tempo.length; c++) 
				{
					if (perkcounter == secondcounter && perk == _perk)
					{
						//self.mDetailsPanel.CharacterName.html("pk "+perkcounter+" sc"+secondcounter);
						self.AddPerk(secondcounter);
					}
					secondcounter +=1;
				}
			}
			perkcounter +=1;
		}
	});
};


var BEFanYi = function(text)
{
	
	text = text.replace("MC_Charm_1", "MC-魅惑一");
	text = text.replace("MC_Charm_2", "MC-魅惑二");
	text = text.replace("MC_Magic", "MC-魔法学习");
	text = text.replace("MC_Other", "MC-其他");
	
	text = text.replace("Bastardsword", "巨剑");
	text = text.replace("Blacksmith hammer", "铁匠锤");
	text = text.replace("Butchers cleaver", "剁肉刀");
	text = text.replace("Estoc", "刺剑");
	text = text.replace("Gladius", "单手剑");
	text = text.replace("Glaive", "长柄刀");
	text = text.replace("Halberd", "长戟");
	text = text.replace("Infantry axe", "步兵斧");
	text = text.replace("Military goedendag", "军棍");
	text = text.replace("Swordstaff", "剑杖");
	text = text.replace("Voulge", "钩镰枪");
	text = text.replace("Bladed pikee", "带刃长矛");
	text = text.replace("Great khopesh", "巨大的霍佩什");
	text = text.replace("Longsword", "长剑");
	text = text.replace("Orc axe 2h", "双手兽人斧");
	text = text.replace("Orc flail 2h", "双手兽人链枷");
	text = text.replace("Royal lance", "皇家长矛");
	text = text.replace("Swordlance", "长柄剑");

	
	text = text.replace("Swordmasters", "剑士");
	text = text.replace("Woodaxe", "伐木斧");
	text = text.replace("GreatSword", "大剑");
	text = text.replace("Polearm", "长柄");
	text = text.replace("Axe", "斧");
	text = text.replace("Bardiche", "月牙砍刀");
	text = text.replace("Battle whip", "战鞭");
	text = text.replace("Billhook", "钩镰枪");
	text = text.replace("Warscythe", "军用镰刀");
	text = text.replace("Cleaver", "砍刀");
	text = text.replace("Crossbow", "弩");
	text = text.replace("Crypt cleaver", "墓穴砍刀");
	text = text.replace("Dagger", "匕首");
	text = text.replace("Fencing sword", "刺剑");
	text = text.replace("Flail", "链枷");
	text = text.replace("Goblin falchion", "哥布林弯形剑");
	text = text.replace("Goblin heavy bow", "哥布林重弓");
	text = text.replace("Goblin pike", "哥布林梭矛");
	text = text.replace("Goblin spear", "哥布林长矛");
	text = text.replace("Greataxe", "双手巨斧");
	text = text.replace("Greatsword", "双手大剑");
	text = text.replace("Handgonne", "手炮");
	text = text.replace("Heavy rusty axe", "生锈重型斧");
	text = text.replace("Javelin", "标枪");
	text = text.replace("Khopesh", "弯刀");
	text = text.replace("Longaxe", "长斧");
	text = text.replace("Mace", "棍棒");
	text = text.replace("Orc axe", "兽人斧");
	text = text.replace("Orc cleaver", "兽人砍刀");
	text = text.replace("Pike", "梭矛");
	text = text.replace("Polehammer", "长锤");
	text = text.replace("Polemace", "长棍");
	text = text.replace("Qatal dagger", "卡塔尔匕首");
	text = text.replace("Rusty warblade", "生锈战刀");
	text = text.replace("Shamshir", "塞施尔弯刀");
	text = text.replace("Skullhammer", "头骨锤");
	text = text.replace("Spear", "长矛");
	text = text.replace("Spetum", "长戟");
	text = text.replace("Sword", "剑");
	text = text.replace("Swordlance", "刃矛");
	text = text.replace("Three headed flail", "三头链枷");
	text = text.replace("Throwing axe", "投斧");
	text = text.replace("Two handed club", "双手棒");
	text = text.replace("Two handed blade", "双手刀");
	text = text.replace("Two handed cleaver", "双手砍刀");
	text = text.replace("Two handed flail", "双手链枷");
	text = text.replace("Two handed hammer", "双手锤");
	text = text.replace("Two handed mace", "双手棍");
	text = text.replace("Warbow", "战弓");
	text = text.replace("Warbrand", "战剑");
	text = text.replace("Warhammer", "战锤");
	text = text.replace("additional padding", "额外的填充物");
	text = text.replace("Barbarian horn", "野蛮人之角");
	text = text.replace("Bone platings", "骨头板");
	text = text.replace("Direwolf pelt", "冰原野狼皮");
	
	text = text.replace("ConditionMax", "最大耐久");
	text = text.replace("StaminaModifier", "疲劳修正");
	text = text.replace("MeleeDefense", "近战防御");
	text = text.replace("RangedDefense", "远程防御");
	text = text.replace("FatigueOnSkillUse", "武器技能疲劳");
	text = text.replace("RegularDamageMax", "最大伤害");
	text = text.replace("RegularDamage", "最小伤害");
	text = text.replace("ArmorDamageMult", "护甲伤害系数");
	text = text.replace("DirectDamageAdd", "穿甲伤害");
	text = text.replace("ChanceToHitHead", "击中头部几率");
	text = text.replace("ShieldDamage", "盾牌伤害");
	text = text.replace("AdditionalAccuracy", "额外命中几率");
	text = text.replace("AmmoMax", "填装量");
	
	text = text.replace("Weapons", "武器");
	text = text.replace("Shields", "盾牌");
	text = text.replace("Helmets", "头盔");
	text = text.replace("Legendary", "传奇");
	text = text.replace("Misc", "杂项");

	text = text.replace("WarlockMagic", "术士法术");
	text = text.replace("VampireMagic", "吸血鬼法术");
	text = text.replace("ZombieMagic", "僵尸法术");
	text = text.replace("SkeletonMagic", "骷髅法术");
	text = text.replace("BerserkerMagic", "狂战士法术");
	text = text.replace("DruidMagic", "德鲁伊法术");
	text = text.replace("CaptainMagic", "队长法术");
	text = text.replace("IllusionistMagic", "幻术法术");
	text = text.replace("ConjurationMagic", "召唤法术");
	text = text.replace("TransmutationMagic", "嬗变法术");
	text = text.replace("EvocationMagic", "塑能法术");
	text = text.replace("PhilosophyMagic", "哲学法术");
	text = text.replace("TherianthropyMagic", "人类法术");
	text = text.replace("ValaRuneMagic", "瓦拉符文法术");
	text = text.replace("InventorMagic", "创造法术");
	text = text.replace("ValaChantMagic", "瓦拉吟唱法术");
	text = text.replace("ValaTranceMagic", "瓦拉通灵法术");
	text = text.replace("RangerHuntMagic", "游侠法术");
	text = text.replace("BasicNecroMagic", "基本巫术");
	text = text.replace("AssassinProfession", "刺客");
	text = text.replace("BlacksmithProfession", "铁匠");
	text = text.replace("MinerProfession", "矿工");
	text = text.replace("FarmerProfession", "农民");
	text = text.replace("HunterProfession", "猎人");
	text = text.replace("DiggerProfession", "挖掘工");
	text = text.replace("LumberjackProfession", "伐木工");
	text = text.replace("ApothecaryProfession", "药剂师");
	text = text.replace("MinstrelProfession", "吟游诗人");
	text = text.replace("HolyManProfession", "神职人员");
	text = text.replace("CultistProfession", "异教徒");
	text = text.replace("TraderProfession", "贸易商");
	text = text.replace("PauperProfession", "穷人");
	text = text.replace("LaborerProfession", "劳工");
	text = text.replace("ServiceProfession", "服务员");
	text = text.replace("RaiderProfession", "掠夺者");
	text = text.replace("SoldierProfession", "士兵");
	text = text.replace("WildlingProfession", "野人");
	text = text.replace("NobleProfession", "贵族");
	text = text.replace("ButcherProfession", "屠夫");
	text = text.replace("JugglerProfession", "杂耍者");
	text = text.replace("MilitiaProfession", "民兵");
	
	text = text.replace("Roster", "名册");
	text = text.replace("Some", "一些");
	text = text.replace("Others", "其他");
	text = text.replace("More", "更多");
	text = text.replace("Hammer", "锤");
	text = text.replace("Bow", "弓");
	text = text.replace("Throwing", "投掷");
	text = text.replace("Slings", "投石器");
	text = text.replace("Staves", "法杖");
	text = text.replace("Shield", "盾牌");
	text = text.replace("HeavyArmor", "重甲");
	text = text.replace("MediumArmor", "中甲");
	text = text.replace("LightArmor", "轻甲");
	text = text.replace("Agile", "敏捷");
	text = text.replace("Indestructible", "坚韧");
	text = text.replace("Martyr", "殉道");
	text = text.replace("Vicious", "残酷");
	text = text.replace("Devious", "狡猾");
	text = text.replace("Inspirational", "鼓舞");
	text = text.replace("Intelligent", "才智");
	text = text.replace("Calm", "镇静");
	text = text.replace("Fast", "快速");
	text = text.replace("Large", "巨大");
	text = text.replace("Organised", "条理");
	text = text.replace("Sturdy", "强健");
	text = text.replace("Fit", "适合");
	text = text.replace("Trained", "受训");
	text = text.replace("Beast", "野兽");
	text = text.replace("Bard", "吟游诗人");
	text = text.replace("Healer", "医师");
	text = text.replace("Faith", "信仰");
	text = text.replace("Fists", "拳击");
	text = text.replace("Chef", "厨师");
	text = text.replace("Repair", "修理");
	text = text.replace("Barter", "交易");
	text = text.replace("Knife", "匕首");
	text = text.replace("Butcher", "屠夫");
	text = text.replace("Hammer", "铁匠");
	text = text.replace("Militia", "民兵");
	text = text.replace("Pickaxe", "镐头");
	text = text.replace("Pitchfork", "草叉");
	text = text.replace("Shortbow", "短弓");
	text = text.replace("Sickle", "镰刀");
	text = text.replace("Ninetails", "九尾鞭");
	text = text.replace("Juggler", "杂耍");
	text = text.replace("Houndmaster", "驯兽师");
	text = text.replace("Shovel", "掘墓人");
	
	text = text.replace("Ghoul", "食尸鬼");
	text = text.replace("Direwolf", "冰原狼");
	text = text.replace("Spider", "蜘蛛");
	text = text.replace("Schrat", "树人");
	text = text.replace("Hexen", "巫师");
	text = text.replace("Alp", "梦魇");
	text = text.replace("Skeleton", "骷髅");
	text = text.replace("Vampire", "吸血鬼");
	text = text.replace("Orc", "兽人");
	text = text.replace("Goblin", "哥布林");
	text = text.replace("Unhold", "巨魔");
	text = text.replace("Zombie", "僵尸");
	text = text.replace("Caravan", "平民");
	text = text.replace("Mercenary", "雇佣兵");
	text = text.replace("Nobles", "贵族");
	text = text.replace("Bandit", "强盗");
	text = text.replace("Barbarians", "野蛮人");
	text = text.replace("Archers", "弓箭手");
	text = text.replace("Southerners", "南方人");
	text = text.replace("Lindwurm", "林德虫");
	text = text.replace("Outlanders", "外地人");
	text = text.replace("Weapons", "武器");
	text = text.replace("Armor", "盔甲");
	text = text.replace("Traits", "特性");
	text = text.replace("Class", "类别");
	text = text.replace("Enemy", "偏好敌人");
	text = text.replace("Magic", "法术");
	text = text.replace("Leftovers", "剩余");
	text = text.replace("Lute", "鲁特琴");
	text = text.replace("Trapper", "捕兽者");
	text = text.replace("Mender", "修理工");
	text = text.replace("Sergeant", "政委");
	text = text.replace("Clerk", "店员");
	text = text.replace("Tactician", "战术家");
	text = text.replace("Entertainer", "艺人");
	text = text.replace("Scout", "侦察员");

	text = text.replace("OneHanded", "单手武器");
	text = text.replace("TwoHanded", "双手武器");
	text = text.replace("Ranged", "远程武器");

	text = text.replace("Profession", "职业");
	text = text.replace("Styles", "风格");
	text = text.replace("Special", "特殊");
	
	
	
	return text;
}