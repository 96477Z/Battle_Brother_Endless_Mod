SQ.call(Screens.MainMenuScreen.getModule("MainMenuModule").mSQHandle, "connectBackend");
