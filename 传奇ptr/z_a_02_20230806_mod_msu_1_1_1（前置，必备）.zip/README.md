# Modding Standards & Utilities
is a modding library for the game [Battle Brothers](https://store.steampowered.com/app/365360/Battle_Brothers/)
allowing for significantly better mod compatibility
and providing common functions for mods.

## Links
[GitHub Repository](https://github.com/MSUTeam/mod_MSU)\
[Nexusmods](https://www.nexusmods.com/battlebrothers/mods/479)

## Authors:
LordMidas ([GitHub](https://github.com/LordMidas), [NexusMods](https://www.nexusmods.com/battlebrothers/users/112721473?tab=user+files))\
Enduriel ([GitHub](https://github.com/Enduriel), [NexusMods](https://www.nexusmods.com/users/59894991?tab=user+files))\
TaroEld ([Github](https://github.com/TaroEld), [NexusMods](https://www.nexusmods.com/battlebrothers/users/3209078?tab=user+files))
